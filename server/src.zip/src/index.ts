import dotenv from "dotenv"
// import * as mediasoup from "mediasoup"
dotenv.config()
import express, { Application, Request, Response } from "express"
import socket from "socket.io";
import http from "http"
// import { initMediasoup, router } from "./states/mediasoupstate"

// // console.log(router.rtpCapabilities);
// initMediasoup().then(() => {
//     // console.log(router);
// })



const PORT = process.env.PORT || 3001;
const app: Application = express()

const httpServer = http.createServer(app);
const io = new socket.Server(httpServer, {
    cors: {
        origin: "*"
    }
})

io.on("connection", (socket) => {
    console.log(`Connection: ${socket.id}`)
})


httpServer.listen(PORT, () => {
    console.log(`Server is running at port ${PORT}`)
})