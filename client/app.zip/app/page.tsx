import Image from "next/image";
import CallWrapper from "@/components/CallWrapper";

export default function Home() {
  return (
    <div>
      <CallWrapper />
    </div>
  );
}
